'use strict';

/* http://docs.angularjs.org/guide/dev_guide.e2e-testing */

