'use strict';

var eventsApp = angular.module('eventsApp', []);
