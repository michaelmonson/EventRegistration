'use strict';

/* jasmine specs for directives go here */


